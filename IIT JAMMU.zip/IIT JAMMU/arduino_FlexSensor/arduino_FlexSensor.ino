int analogPin= 0;
int raw= 0;

int Vin= 5;
float Vout= 0; // unknown voltage, we have to measure
float R1= 82000;
float R2= 0; // Unknown resistance, we have to measure
float buffer= 0;
void setup(){
  Serial.begin(9600);
}

void loop(){
  raw= analogRead(analogPin);
  if(raw){
    buffer= raw * Vin;
    Vout= (buffer)/1024.0;
    buffer= (Vin/Vout) -1;
    R2= R1 * buffer;
    Serial.println(R2);
    delay(200); // resistance value is measured per second
  }
}